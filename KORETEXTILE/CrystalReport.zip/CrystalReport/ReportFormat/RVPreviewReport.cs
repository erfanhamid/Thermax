﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BEEERP.CrystalReport.ReportFormat
{
    public class RVPreviewReport
    {
        public string Particulars { set; get; }
        public string Description { set; get; }
        public double Amount { set; get; }
    }
}