﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BEEERP.CrystalReport.ReportFormat
{
    public class MRVAPreviewReport
    {
        public int Code { get; set; }
        public string AccountHead { get; set; }
        public string CostGroup { get; set; }
        public string Descriptions { get; set; }
        public decimal DrAmount { get; set; }
        public decimal CrAmount { get; set; }
    }
}