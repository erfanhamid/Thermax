﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BEEERP.CrystalReport.ReportFormat
{
    public class HolidayDetailsR
    {
       
            public string HolidayName { get; set; }
            public DateTime HolidayDate { get; set; }

        
    }
}