﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BEEERP.CrystalReport.ReportFormat
{
    public class LCRNSamplePreviewReport
    {
        public string Name { get; set; }
        public string PacSize { get; set; }
        public decimal Qty { get; set; }
    }
}