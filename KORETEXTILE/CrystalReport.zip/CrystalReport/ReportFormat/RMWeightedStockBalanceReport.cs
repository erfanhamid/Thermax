﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BEEERP.CrystalReport.ReportFormat
{
    public class RMWeightedStockBalanceReport
    {
        public string GroupName { get; set; }
        public string ItemName { get; set; }
        public int CIID { get; set; }
        public string UOM { get; set; }
        public decimal ObUnitPrice { get; set; }
        public double ObQty { get; set; }
        public double ObAmount { get; set; }
        public decimal PurcahseUnitPrice { get; set; }
        public decimal PurcahseQty { get; set; }
        public decimal PurchaseAmount { get; set; }
        public decimal IssueQty { get; set; }
        public decimal IssueRate { get; set; }
        public decimal IssueAmount { get; set; }
        public decimal ClosingRate { get; set; }
        public decimal ClosingQty { get; set; }
        public decimal ClosingAmount { get; set; }
    }
}