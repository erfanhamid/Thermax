﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BEEERP.CrystalReport.ReportFormat
{
    public class TsoWiseTrackingHistory
    {
        public string TSOName { get; set; }
        public string CustomerName { get; set; }
        public string Status { get; set; }
    }
}