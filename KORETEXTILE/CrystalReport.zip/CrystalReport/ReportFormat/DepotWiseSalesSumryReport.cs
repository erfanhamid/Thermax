﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BEEERP.CrystalReport.ReportFormat
{
    public class DepotWiseSalesSumryReport
    {
        public string DepotName { set; get; }
        public string AreaName { set; get; }
        public decimal Amount { set; get; }
    }
}