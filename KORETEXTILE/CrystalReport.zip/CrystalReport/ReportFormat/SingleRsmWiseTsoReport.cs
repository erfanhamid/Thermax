﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BEEERP.CrystalReport.ReportFormat
{
    public class SingleRsmWiseTsoReport
    {
        public string TsoName { get; set; }
        public int TsoID { get; set; }
        public string Contact { get; set; }
        public string Email { get; set; }
        public string Name { get; set; }
    }
}