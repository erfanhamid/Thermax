﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BEEERP.CrystalReport.ReportFormat
{
    public class FTVPreviewReport
    {
        public string Description { set; get; }
        public double Amount { set; get; }
    }
}